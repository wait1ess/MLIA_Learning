# 第8周

## 课程内容

- 《机器学习实战》第 12 章：使用 FP-growth 算法来发现频繁项集

## 包含文件

- Reference Code：参考代码

- Assignment：作业


