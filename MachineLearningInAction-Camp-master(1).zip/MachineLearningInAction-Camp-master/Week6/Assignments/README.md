# 本周作业

## 包含文件

- Reference：参考答案和代码（作业第二天上传至 GitHub）

- Submission：学员提交的优秀答案（从所有学员提交的答案中选择最佳答案若干，上传至 GitHub）

## 作业

- 第一节：

  - 1.将本章中“在一个难数据集上应用AdaBoost”完整代码键入jupyter notebook，并添加详细注释。若有可能，自己可以优化该代码。
  
  - 2.将本章中“使用Python的Tkinter库创建GUI”完整代码键入jupyter notebook，并添加详细注释。若有可能，自己可以优化该代码。
  
- 第二节：

  - 1.将本章10.4.2中“对地理坐标进行聚类”完整代码键入jupyter notebook，并添加详细注释。若有可能，自己可以优化该代码。

