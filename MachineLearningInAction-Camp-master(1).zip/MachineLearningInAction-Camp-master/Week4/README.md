# 第四周

## 课程内容

- 《机器学习实战》第 6 章 6.4/6.5/6.6 节：支持向量机

- 天池o2o预测赛（初级）

## 包含文件

- Reference Code：参考代码

- Assignment：作业

- o2o Code_Easy：天池 o2o 预测赛（初级）代码、流程介绍 PPT、代码解析 PPT

## 参考资料

李航《统计学习方法》第 7 章

[深入浅出机器学习技法（一）：线性支持向量机（LSVM）](https://mp.weixin.qq.com/s/Ahvp0IAdgK9OVHFXigBk_Q)

[深入浅出机器学习技法（二）：对偶支持向量机（DSVM）](https://mp.weixin.qq.com/s/Q5bFR3vDDXPhtzXlVAE3Rg)

[深入浅出机器学习技法（三）：核支持向量机（KSVM）](https://mp.weixin.qq.com/s/cLovkwwgGJRgSSa1XWZ8eg)
