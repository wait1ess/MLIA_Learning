# 第7周

## 课程内容

- 《机器学习实战》第 11 章：使用 Apriori 算法进行关联分析

## 包含文件

- Reference Code：参考代码

- Assignment：作业


