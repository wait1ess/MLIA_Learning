# 参考答案

## assignment_1.2.ipynb

- 第一节第2个作业参考答案。建议使用jupyter，因为可以添加解释性文档。

